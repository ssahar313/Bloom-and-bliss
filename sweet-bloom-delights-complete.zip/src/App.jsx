import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-pink-50 text-gray-900">
      <h1 className="text-4xl font-bold text-primary mb-4">Sweet Bloom Delights</h1>
      <p className="text-lg text-center max-w-xl">
        Hand-crafted chocolate-covered strawberries and stunning edible bouquets made with love.
      </p>
    </div>
  );
}
