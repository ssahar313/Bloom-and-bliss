import React from "react";
import { Button } from "./components/ui/button";
import { Card, CardContent } from "./components/ui/card";
import { Input } from "./components/ui/input";
import { motion } from "framer-motion";

const products = [
  {
    name: "Classic Strawberries",
    description: "Fresh strawberries dipped in milk chocolate.",
    price: "$25",
    image: "/images/classic-strawberries.jpg",
  },
  {
    name: "Deluxe Bouquets",
    description: "Mixed flower bouquets with seasonal selections.",
    price: "$45",
    image: "/images/deluxe-bouquet.jpg",
  },
  {
    name: "Romantic Combo",
    description: "Chocolate strawberries with a rose bouquet.",
    price: "$60",
    image: "/images/romantic-combo.jpg",
  },
];

export default function App() {
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <header className="text-center mb-10">
        <motion.h1
          className="text-4xl font-bold text-pink-700"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Sweet Bloom Delights
        </motion.h1>
        <p className="text-gray-600 text-lg mt-2">
          Chocolate Covered Strawberries & Bouquets
        </p>
      </header>

      <div className="grid md:grid-cols-3 gap-6">
        {products.map((product, idx) => (
          <Card key={idx} className="rounded-2xl shadow-lg overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-48 object-cover"
            />
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold text-pink-600">
                {product.name}
              </h2>
              <p className="text-sm text-gray-500 mt-1">
                {product.description}
              </p>
              <div className="flex justify-between items-center mt-4">
                <span className="text-lg font-bold">{product.price}</span>
                <Button className="bg-pink-600 hover:bg-pink-700 text-white">
                  Order
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <section className="mt-16 bg-pink-50 p-6 rounded-2xl shadow-inner">
        <h3 className="text-2xl font-semibold text-pink-700 mb-4">
          Get in Touch
        </h3>
        <form className="grid md:grid-cols-2 gap-4">
          <Input placeholder="Your Name" />
          <Input placeholder="Your Email" />
          <Input className="md:col-span-2" placeholder="Your Message" />
          <Button className="md:col-span-2 bg-pink-600 hover:bg-pink-700 text-white">
            Send Message
          </Button>
        </form>
      </section>
    </div>
  );
}
