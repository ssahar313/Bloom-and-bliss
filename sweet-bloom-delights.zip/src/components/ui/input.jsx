export function Input({ className = "", ...props }) {
  return (
    <input
      className={`border border-gray-300 p-2 rounded-xl w-full ${className}`}
      {...props}
    />
  );
}
